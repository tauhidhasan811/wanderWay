// rag.js

function validateForm() {
    let fullName = document.forms["tourGuideForm"]["full_name"].value;
    let email = document.forms["tourGuideForm"]["email"].value;
    let phone = document.forms["tourGuideForm"]["phone"].value;
    let password = document.forms["tourGuideForm"]["password"].value;
    let confirmPassword = document.forms["tourGuideForm"]["confirm_password"].value;
    let gender = document.forms["tourGuideForm"]["gender"].value;
    let dob = document.forms["tourGuideForm"]["dob"].value;
    let address = document.forms["tourGuideForm"]["address"].value;
    let experience = document.forms["tourGuideForm"]["experience"].value;
    let languages = document.forms["tourGuideForm"]["languages"].value;
    let locations = document.forms["tourGuideForm"]["locations"].value;
    let drivingExperience = document.forms["tourGuideForm"]["driving_experience"].value;
    let passportNumber = document.forms["tourGuideForm"]["passport_number"].value;
    let nationality = document.forms["tourGuideForm"]["nationality"].value;
    let availability = document.forms["tourGuideForm"]["availability"].value;

    // Checking if any required field is empty
    if (fullName == "" || email == "" || phone == "" || password == "" || confirmPassword == "" ||
        gender == "" || dob == "" || address == "" || experience == "" || languages == "" ||
        locations == "" || drivingExperience == "" || passportNumber == "" || nationality == "" || availability == "") {
        alert("Please fill in all the fields.");
        return false;
    }

    // Check if passwords match
    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return false;
    }

    // If all checks pass, return true to allow form submission
    return true;
}
